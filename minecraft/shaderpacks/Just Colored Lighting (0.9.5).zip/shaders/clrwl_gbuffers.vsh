#version 430 compatibility

#define IS_TERRAIN 1
#define IS_COLOR_WHEEL 1

#include "/main_v.glsl"
