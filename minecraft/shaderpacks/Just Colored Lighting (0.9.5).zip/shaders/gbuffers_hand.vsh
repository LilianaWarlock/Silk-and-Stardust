#version 430 compatibility
#define IS_HAND 1

#include "/main_v.glsl"
