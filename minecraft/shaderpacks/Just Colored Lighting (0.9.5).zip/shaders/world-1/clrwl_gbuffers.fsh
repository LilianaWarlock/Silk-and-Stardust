#version 430 compatibility

#define FILTER_HERE UPSCALE_TERRAIN

#define IS_AN_ENTITY 1
#define IS_COLOR_WHEEL 1


#include "/main_f.glsl"
