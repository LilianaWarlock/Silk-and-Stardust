‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵︵‿୨ ♡ ୧‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿
‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵

# ‿︵‿︵‿︵‿︵‿︵‿୨ Introduction ୧‿︵‿︵‿︵‿︵‿︵‿

### --- **Thank you for downloading Melody's Jellyfish!** ---

#### [**♡ Discord**](https://discord.gg/XuJCkpgCUs)
#### [**♡ Website**](https://melodymews.com/?utm_source=jfpackrdme&utm_medium=jfpackrdme&utm_campaign=jfpackrdme&utm_term=jfpackrdme)

> [!IMPORTANT]
> This pack has been tested to work on **OptiFine 1.18.1 HD U H5** and higher. (Ignore the warning it gives when you try to add it)


# ‿︵‿︵‿︵‿︵‿︵‿୨ Updates ୧‿︵‿︵‿︵‿︵‿︵‿

## ♡ 03/03/2026 v1.0.3
### • Fixed wrong Updates in readme file.

## ♡ 03/03/2026 v1.0.2
### • Updated supported formats in pack.meta file.


# ‿︵‿︵‿︵‿︵‿︵‿୨ Licensing ୧‿︵‿︵‿︵‿︵‿︵‿

### • Do not resell this pack or its files.
### • Do not redistribute this pack or its files.
### • You are allowed to edit the pack only for personal use and not commercial.
### • You are allowed to stream, screenshot, and make videos with this pack but give credit to me.
### • Keep it wholesome. Don’t use or edit this pack to show gore, torture, or NSFW content. No nudity, fetish/erotic content, or sexualized depictions of minors/age-ambiguous characters.
### • Use is prohibited for anyone who has engaged in harassment, hate speech, doxxing, cheating, or other malicious conduct toward me or my community, or whose name appears on my blocklist.
### • These rules are subject to change at any time.

‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿︵‿
