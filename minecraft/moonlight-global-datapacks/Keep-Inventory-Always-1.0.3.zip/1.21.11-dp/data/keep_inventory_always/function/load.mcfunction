gamerule keep_inventory true
